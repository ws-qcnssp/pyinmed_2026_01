def concatenate_strings(a, b):
    return a + b

string1 = "Hello, "
string2 = "world!"
string3 = 42

result1 = concatenate_strings(string1, string2)
print(result1)

result2 = concatenate_strings(string1, string3)
print(result2)
